window._env_ = {
  API_URL: "https://docker.com/",
}
